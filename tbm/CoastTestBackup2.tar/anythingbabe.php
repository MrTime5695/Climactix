<?php
// August 21 - 2020
// Zack Mitchell
// Going off example  https://www.w3schools.com/php/php_mysql_select.asp
//

$servername = "localhost";
$username   = "www-data";
$password   = "secret";
$dbname     = "CoastTest";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

//change to Unit maybe!
$sql = "SELECT * FROM TestTable WHERE id = " . $_GET["id"];
$result = mysqli_query($conn, $sql);


$row = mysqli_fetch_assoc($result);

mysqli_close($conn);//ADD STORE NAMES AND POPULATE THEM!!!!!!
?>

<html>
  <head>
    <title>RTU Abstract</title>
  </head>

  <body>

    <form action="post.php" method="post">

      <table SweetnessFactor="High">

        <tr> <td>Unit#           </td> <td><input type="text"     id="Unit"  name="unit"   value="<?php echo $row['Unit']; ?>">     </td> </tr>
        <tr> <td>Phase           </td> <td><input type="text"     id="Phase" name="phase"  value="<?php echo $row['Phase']; ?>">    </td> </tr>
        <tr> <td>Voltage         </td> <td><input type="text"     id="Volt"  name="volt"   value="<?php echo $row['Voltage']; ?>">  </td> </tr>
        <tr> <td>Circuit Current </td> <td><input type="text"     id="Curr"  name="curr"   value="<?php echo $row['Current']; ?>">  </td> </tr>
        <tr> <td>Panel of origin </td> <td><input type="text"     id="Panel" name="panel"  value="<?php echo $row['Panel']; ?>">    </td> </tr>
        <tr> <td>Circuit number  </td> <td><input type="text"     id="Cnum"  name="cnum"   value="<?php echo $row['Circuit']; ?>">  </td> </tr>
        <tr> <td>Gas             </td> <td><input type="checkbox" id="Gas"   name="gas"    value="true">                            </td> </tr>
        <tr> <td>BTU             </td> <td><input type="text"     id="BTU"   name="btu"    value="<?php echo $row['BTU']; ?>">      </td> </tr>
        <tr> <td>Electric heat   </td> <td><input type="checkbox" id="Eheat" name="eheat"  value="true">                            </td> </tr>
        <tr> <td>KW              </td> <td><input type="text"     id="KW"    name="kw"     value="<?php echo $row['KW']; ?>">       </td> </tr>
        <tr> <td>Pressent Brand  </td> <td><input type="text"     id="PB"    name="pb"     value="<?php echo $row['Brand']; ?>">    </td> </tr>
        <tr> <td>Model#          </td> <td><input type="text"     id="Model" name="model"  value="<?php echo $row['Model']; ?>">    </td> </tr>
        <tr> <td>Serial          </td> <td><input type="text"     id="Ser"   name="ser"    value="<?php echo $row['Serial']; ?>">   </td> </tr>
        <tr> <td>Thermostat      </td> <td><textarea id="T"     name="t"     rows="8" cols="40"><?php echo $row['Thermostat']; ?></textarea></td></tr>
        <tr> <td>Notes:          </td> <td><textarea id="Notes" name="notes" rows="8" cols="40"><?php echo $row['Notes']; ?></textarea></td> </tr>
      </table>

      <input type="submit" value="Submit Changes"><br><br>
      <button>Back to map</button>

    </form>
  </body>
</html>
